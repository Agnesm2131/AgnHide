package me.agneshide;

import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HideListener implements Listener {

    private final AgnesHide plugin;
    private final Map<UUID, Long> clickCooldown = new HashMap<>();

    public HideListener(AgnesHide plugin) {
        this.plugin = plugin;
    }

    private boolean hasCooldown(Player player) {
        FileConfiguration config = plugin.getConfig();
        long now = System.currentTimeMillis();
        if (clickCooldown.containsKey(player.getUniqueId())) {
            long lastClick = clickCooldown.get(player.getUniqueId());
            if (now - lastClick < config.getLong("settings.click-cooldown", 1000)) {
                String cooldownMsg = config.getString("messages.cooldown", "&cLütfen tekrar denemeden önce bekleyin!");
                player.sendMessage(cooldownMsg.replace("&", "§"));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.5f);
                return true;
            }
        }
        clickCooldown.put(player.getUniqueId(), now);
        return false;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getHideManager().giveItems(event.getPlayer());
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (hasCooldown(player)) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        FileConfiguration config = plugin.getConfig();

        String visibleName = config.getString("item.visible.name").replace("&", "§");
        String hiddenName = config.getString("item.hidden.name").replace("&", "§");
        String compassName = config.getString("compass.name").replace("&", "§");
        String profileName = config.getString("profile.name").replace("&", "§");
        String tntName = config.getString("tntitem.name").replace("&", "§");

        String itemName = item.getItemMeta().getDisplayName();

        // Oyuncu gizle/aç
        if (itemName.equals(visibleName) || itemName.equals(hiddenName)) {
            plugin.getHideManager().togglePlayerVisibility(player);
            return;
        }

        // Pusula
        if (itemName.equals(compassName)) {
            for (String command : config.getStringList("compass.commands")) {
                sendChatCommand(player, command);
            }
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
            return;
        }

        // Profil kafası
        if (itemName.equals(profileName)) {
            String command = config.getString("profile.command");
            if (command != null) {
                sendChatCommand(player, command);
            }
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
            return;
        }

        // TNT vagonu
        if (itemName.equals(tntName)) {
            String command = config.getString("tntitem.command");
            if (command != null) {
                sendChatCommand(player, command);
            }
            player.playSound(player.getLocation(), Sound.ENTITY_TNT_PRIMED, 1f, 1f);
        }
    }

    private void sendChatCommand(Player player, String command) {
        if (!command.startsWith("/")) {
            command = "/" + command;
        }
        player.chat(command.replace("{player}", player.getName()));
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        FileConfiguration config = plugin.getConfig();

        int hideSlot = config.getInt("item.slot");
        int compassSlot = config.getInt("compass.slot");
        int profileSlot = config.getInt("profile.slot");
        int tntSlot = config.getInt("tntitem.slot");

        int clickedSlot = event.getSlot();

        if (clickedSlot == hideSlot || clickedSlot == compassSlot || clickedSlot == profileSlot || clickedSlot == tntSlot) {
            event.setCancelled(true);
        }
    }
}

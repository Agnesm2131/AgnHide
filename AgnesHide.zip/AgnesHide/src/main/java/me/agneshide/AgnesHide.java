package me.agneshide;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AgnesHide extends JavaPlugin {

    private static AgnesHide instance;
    private HideManager hideManager;
    private Set<UUID> hiddenPlayers = new HashSet<>();
    private FileConfiguration messages;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        saveResource("messages.yml", false);
        reloadMessages();

        hideManager = new HideManager(this);
        getServer().getPluginManager().registerEvents(new HideListener(this), this);
        getCommand("agnhide").setExecutor(new ReloadCommand(this));
    }

    public static AgnesHide getInstance() {
        return instance;
    }

    public HideManager getHideManager() {
        return hideManager;
    }

    public Set<UUID> getHiddenPlayers() {
        return hiddenPlayers;
    }

    public FileConfiguration getMessages() {
        return messages;
    }

    public void reloadMessages() {
        File file = new File(getDataFolder(), "messages.yml");
        messages = YamlConfiguration.loadConfiguration(file);
    }
}

package me.agneshide;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class HideManager {

    private final AgnesHide plugin;
    private final Set<Player> hiddenPlayers = new HashSet<>();
    private final Map<UUID, Long> itemCooldowns = new HashMap<>();

    public HideManager(AgnesHide plugin) {
        this.plugin = plugin;
    }

    public void giveItems(Player player) {
        FileConfiguration config = plugin.getConfig();

        // Oyuncu görünürlük itemi
        ItemStack visibleItem = createItem(
                Material.valueOf(config.getString("item.visible.material")),
                config.getString("item.visible.name")
        );
        ItemStack hiddenItem = createItem(
                Material.valueOf(config.getString("item.hidden.material")),
                config.getString("item.hidden.name")
        );
        int hideSlot = config.getInt("item.slot");

        if (hiddenPlayers.contains(player)) {
            player.getInventory().setItem(hideSlot, hiddenItem);
        } else {
            player.getInventory().setItem(hideSlot, visibleItem);
        }

        // Compass
        ItemStack compass = createItem(
                Material.valueOf(config.getString("compass.material")),
                config.getString("compass.name")
        );
        player.getInventory().setItem(config.getInt("compass.slot"), compass);

        // Profil kafası
        ItemStack profileHead = createPlayerHead(player.getName(), config.getString("profile.name"));
        player.getInventory().setItem(config.getInt("profile.slot"), profileHead);

        // TNT vagonu
        ItemStack tntMinecart = createItem(
                Material.valueOf(config.getString("tntitem.material")),
                config.getString("tntitem.name")
        );
        player.getInventory().setItem(config.getInt("tntitem.slot"), tntMinecart);
    }

    public void togglePlayerVisibility(Player player) {
        FileConfiguration config = plugin.getConfig();

        if (hiddenPlayers.contains(player)) {
            // Oyuncuları tekrar göster
            hiddenPlayers.remove(player);
            for (Player online : Bukkit.getOnlinePlayers()) {
                player.showPlayer(plugin, online);
            }
            player.getInventory().setItem(
                    config.getInt("item.slot"),
                    createItem(
                            Material.valueOf(config.getString("item.visible.material")),
                            config.getString("item.visible.name")
                    )
            );
            // Title & Subtitle
            player.sendTitle(
                    config.getString("messages.visibility-on-title", "&aOyuncular Açık").replace("&", "§"),
                    config.getString("messages.visibility-on-subtitle", "&7Artık tüm oyuncuları görebilirsin!").replace("&", "§"),
                    10, 40, 10
            );
            // Açma sesi
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.5f);

        } else {
            // Oyuncuları gizle
            hiddenPlayers.add(player);
            for (Player online : Bukkit.getOnlinePlayers()) {
                player.hidePlayer(plugin, online);
            }
            player.getInventory().setItem(
                    config.getInt("item.slot"),
                    createItem(
                            Material.valueOf(config.getString("item.hidden.material")),
                            config.getString("item.hidden.name")
                    )
            );
            // Title & Subtitle
            player.sendTitle(
                    config.getString("messages.visibility-off-title", "&cOyuncular Kapalı").replace("&", "§"),
                    config.getString("messages.visibility-off-subtitle", "&7Artık kimseyi göremeyeceksin!").replace("&", "§"),
                    10, 40, 10
            );
            // Kapama sesi
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_SCREAM, 1f, 0.8f);
        }
    }

    public boolean isOnCooldown(Player player) {
        long now = System.currentTimeMillis();
        if (itemCooldowns.containsKey(player.getUniqueId())) {
            long lastUse = itemCooldowns.get(player.getUniqueId());
            long cooldown = plugin.getConfig().getLong("settings.item-cooldown-ms", 1000);
            if ((now - lastUse) < cooldown) {
                long remaining = (cooldown - (now - lastUse)) / 1000;
                player.sendMessage("§cBu eşyayı tekrar kullanmak için " + remaining + " saniye beklemelisin!");
                return true;
            }
        }
        itemCooldowns.put(player.getUniqueId(), now);
        return false;
    }

    private ItemStack createItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null && name != null) {
            meta.setDisplayName(name.replace("&", "§"));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createPlayerHead(String playerName, String displayName) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(playerName));
            meta.setDisplayName(displayName.replace("&", "§"));
            skull.setItemMeta(meta);
        }
        return skull;
    }

    public void giveItemsToAllOnlinePlayers() {
        for (Player onlinePlayer : plugin.getServer().getOnlinePlayers()) {
            giveItems(onlinePlayer);
        }
    }
}

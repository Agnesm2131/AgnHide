package me.agneshide;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements CommandExecutor {

    private final AgnesHide plugin;

    public ReloadCommand(AgnesHide plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        plugin.reloadConfig();
        plugin.getHideManager().giveItemsToAllOnlinePlayers();
        sender.sendMessage("§aAgnHide config yeniden yüklendi ve tüm oyunculara itemler verildi.");
        return true;
    }
}
